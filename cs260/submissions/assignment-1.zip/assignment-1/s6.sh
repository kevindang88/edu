#!/bin/sh
i=0
while [ $i -le 9 ]; do
  echo $i
  i=`expr $i + 1`
done
